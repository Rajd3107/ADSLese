import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = () => {
    axios
      .post('http://localhost:3001/register', { username, password })
      .then(response => {
        console.log(response.data.message);
      })
      .catch(error => {
        console.error('Error registering user:', error);
      });
  };

  const handleLogin = () => {
    axios
      .post('http://localhost:3001/login', { username, password })
      .then(response => {
        console.log(response.data.message);
      })
      .catch(error => {
        console.error('Error authenticating user:', error);
      });
  };

  return (
    <div>
      <h1>Simple Login/Register</h1>
      <div>
        <label>Username:</label>
        <input
          type="text"
          value={username}
          onChange={e => setUsername(e.target.value)}
        />
      </div>
      <div>
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
      </div>
      <button onClick={handleRegister}>Register</button>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default App;

