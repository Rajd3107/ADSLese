const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(cors());
const port = 3001;

// Configure MySQL connection
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'suraj',
  database: 'register',
});

// Register endpoint
app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
  pool.query(sql, [username, password], (err, result) => {
    if (err) {
      console.error('Error registering user:', err);
      res.status(500).json({ message: 'Internal server error' });
      return;
    }
    res.status(200).json({ message: 'User registered successfully' });
  });
});

// Login endpoint
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
  pool.query(sql, [username, password], (err, result) => {
    if (err) {
      console.error('Error authenticating user:', err);
      res.status(500).json({ message: 'Internal server error' });
      return;
    }
    if (result.length === 0) {
      res.status(401).json({ message: 'Invalid username or password' });
      return;
    }
    res.status(200).json({ message: 'User authenticated successfully' });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
